package http://nightingaleproject.github.io/fhirDeathRecord/ImplementationGuide/1;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class EducationExtension {

}
